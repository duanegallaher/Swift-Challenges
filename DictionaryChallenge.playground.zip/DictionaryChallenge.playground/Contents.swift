import Cocoa

var myTeams = ["Titans": ["Bob","Joe","Billy","Dan","Jill"], "Hawks": ["Frank","John","Matthew","Eric","Jack"], "Eagles": ["Swen","Olie","Helga","Errin","Gloggler"], "Falsons": ["Clyde","Dale","Elden","Fred","Hank","Ike","Jake"]]

myTeams.count

for teams in myTeams.keys {
    let matchTeam = teams                //Current team being processed
    let players = myTeams[matchTeam]     //Players in current team
    _ = Array(arrayLiteral: players)     //Create an array of players
   
    print("\(teams) members:  ")
    for i in players! {                  // Use ! to remove optional
        print(i)
    }
    print("  \n ")
}
